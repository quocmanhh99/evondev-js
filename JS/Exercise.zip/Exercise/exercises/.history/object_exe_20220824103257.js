// 1. Viết 1 function kiểm tra value có phải là object hay không ?
