// Bài 1: Nhập vào số tuổi và kiểm tra nếu số tuổi lớn hơn hoặc bằng 18 thì được coi phim rạp ngược lại thì không được vô coi
// Bài 2: Cho 2 số a và b, tìm ra số lớn hơn