// 1. Đảo ngược một chuỗi. Ví dụ: "My name is evondev" -> "evondev is name My";
