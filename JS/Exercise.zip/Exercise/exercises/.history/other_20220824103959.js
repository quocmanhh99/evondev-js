// 1. arrayReplace
// [1,2,3,1,1] -> [5,2,3,5,5]
// 2. Palindrome
// aaBAA -> AABaa -> Palindrome
// aaBAc -> cABaa -> is not palindrome
// 3. Array Chunking
// [1,2,3,4,5,6,7,8], 3
// [[1,2,3],[4,5,6],[7,8]]
// [[1,2],[3,4],[5,6],[7,8]]
// 4. Reverse array
// [1,2,3,4,5] -> [5,4,3,2,1]
// reverse()