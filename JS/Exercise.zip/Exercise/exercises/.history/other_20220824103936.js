// 1. arrayReplace
// [1,2,3,1,1] -> [5,2,3,5,5]
// 2. Palindrome
// aaBAA -> AABaa -> Palindrome
// aaBAc -> cABaa -> is not palindrome