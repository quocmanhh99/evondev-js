// 1. Đảo ngược một chuỗi. Ví dụ: "My name is evondev" -> "evondev is name My";
// 2. Đảo ngược một chuỗi bao gôm các kí tự. Ví dụ: "i love" -> "evol i"
