// 1. Viết function(hàm) so sánh 2 số a, b tìm ra số lớn hơn
