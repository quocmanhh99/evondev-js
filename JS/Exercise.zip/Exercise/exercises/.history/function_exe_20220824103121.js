// 1. Viết function(hàm) so sánh 2 số a, b tìm ra số lớn hơn
// 2. In hoa chữ cái đầu trong chữ ví dụ: tuan -> Tuan, NAM -> Nam
