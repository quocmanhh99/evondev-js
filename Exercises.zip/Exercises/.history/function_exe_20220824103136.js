// 1. Viết function(hàm) so sánh 2 số a, b tìm ra số lớn hơn
// 2. In hoa chữ cái đầu trong chữ ví dụ: tuan -> Tuan, NAM -> Nam
// 3. Viết hàm có sử dụng callback (function là parameter của function khác) in ra kết quả của hàm compare đã viết ở trên
