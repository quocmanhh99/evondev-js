// 1. Viết 1 function kiểm tra value có phải là object hay không ?
// 2. {a: 1, b: 2} -> [["a", 1], ["b", 2]]
// 3. ({ a: 1, b: 2 }, 'b') => { a: 1 }
